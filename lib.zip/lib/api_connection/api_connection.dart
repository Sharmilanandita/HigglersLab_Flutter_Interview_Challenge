class API
{
  static const hostConnect="http://192.168.8.204/api_movie_app";
  static const hostConnectAdmin="$hostConnect/admin";
  static const hostMovie="$hostConnect/movie";


  static const uploadMovieItems="$hostConnectAdmin/upload.php";
  static const allMovieItems="$hostMovie/all.php";

}